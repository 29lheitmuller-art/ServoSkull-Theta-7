#!/usr/bin/env python3
"""
Component Test Script for Servo-Skull Theta-7 (Zero 2W USB)
Run individual hardware/service tests.
"""

import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from servo_skull.config import load_settings


async def test_config():
    print("=== Testing Config ===")
    settings = load_settings()
    print(f"Skull Name: {settings.servo_skull.name}")
    print(f"NVIDIA Chat: {settings.nvidia.chat_model}")
    print(f"NVIDIA Vision: {settings.nvidia.vision_model}")
    print(f"NVIDIA ASR: {settings.nvidia.asr_model}")
    print(f"Piper Model: {settings.piper.model}")
    print(f"Camera: {settings.hardware.camera_device} @ {settings.hardware.camera_width}x{settings.hardware.camera_height}")
    print(f"Audio In: {settings.hardware.audio_input_device}")
    print(f"Audio Out: {settings.hardware.audio_output_device}")
    print(f"Max Record: {settings.hardware.max_record_seconds}s")
    print("✓ Config loaded\n")


async def list_devices():
    print("=== Listing Devices ===")
    # List cameras
    print("\n--- Cameras ---")
    try:
        import subprocess
        result = subprocess.run(["v4l2-ctl", "--list-devices"], capture_output=True, text=True)
        print(result.stdout or "No cameras found")
    except Exception as e:
        print(f"Error: {e}")

    # List audio devices
    print("\n--- Audio Devices ---")
    try:
        import sounddevice as sd
        devices = sd.query_devices()
        for idx, dev in enumerate(devices):
            in_ch = dev["max_input_channels"]
            out_ch = dev["max_output_channels"]
            if in_ch > 0 or out_ch > 0:
                print(f"  [{idx}] {dev['name']}  (in:{in_ch} out:{out_ch} @ {dev['default_samplerate']:.0f}Hz)")
    except Exception as e:
        print(f"Error: {e}")
    print()


async def test_camera():
    print("=== Testing USB Camera ===")
    from servo_skull.hardware import Camera
    cam = Camera()
    if cam.initialize():
        stats = cam.get_stats()
        print(f"  Device: {stats['device']}")
        print(f"  Resolution: {stats['resolution']} @ {stats['fps']}fps")
        print(f"  Format: {stats['fourcc']}")
        b64 = cam.capture_base64()
        if b64:
            print(f"✓ Capture: {len(b64)} bytes base64")
        else:
            print("✗ Capture failed")
        cam.shutdown()
    else:
        print("✗ Camera initialization failed")
    print()


async def test_light():
    print("=== Testing LED Ring ===")
    from servo_skull.hardware import LightRing
    light = LightRing()
    light.initialize()
    print("  STARTUP...")
    light.set_state(light.LightState.STARTUP)
    await asyncio.sleep(3)
    print("  IDLE...")
    light.set_state(light.LightState.IDLE)
    await asyncio.sleep(2)
    print("  RECORDING...")
    light.set_state(light.LightState.RECORDING)
    await asyncio.sleep(1)
    print("  THINKING...")
    light.set_state(light.LightState.THINKING)
    await asyncio.sleep(1)
    print("  ERROR...")
    light.set_state(light.LightState.ERROR)
    await asyncio.sleep(1)
    await light.shutdown()
    print("✓ Light animations complete\n")


async def test_audio_recorder():
    print("=== Testing USB Microphone ===")
    from servo_skull.hardware import AudioRecorder
    rec = AudioRecorder()
    print("  Recording 3 seconds... (speak now)")
    if rec.start():
        await asyncio.sleep(3)
        wav = rec.stop()
        if wav:
            print(f"✓ Recorded: {len(wav)} bytes WAV")
        else:
            print("✗ No audio data")
    else:
        print("✗ Failed to start recording")
    rec.shutdown()
    print()


async def test_piper():
    print("=== Testing Piper TTS ===")
    from servo_skull.hardware import AudioPlayer
    player = AudioPlayer()
    if player.check_model():
        print("  Speaking test phrase...")
        ok = await player.speak("Rites of activation complete. The Emperor protects.")
        if ok:
            print("✓ Piper TTS working via USB audio")
        else:
            print("✗ Piper playback failed")
    else:
        print("✗ Piper model not found. Run: piper --model en_GB-alba-medium --download-dir models/")
    print()


async def test_nvidia():
    print("=== Testing NVIDIA API ===")
    from servo_skull.services import NVIDIAClient
    client = NVIDIAClient()
    print("  Health check...")
    ok = await client.health_check()
    if ok:
        print("✓ NVIDIA API reachable")
        print("  Testing chat...")
        resp = await client.chat_completion([
            {"role": "user", "content": "Status report, servo-skull."}
        ])
        print(f"  Response: {resp.content[:150]}...")
        print(f"  Latency: {resp.latency_ms}ms")
    else:
        print("✗ NVIDIA API failed (check API key in .env)")
    await client.close()
    print()


async def test_nvidia_vision():
    print("=== Testing NVIDIA Vision (USB Camera) ===")
    from servo_skull.services import NVIDIAClient
    from servo_skull.hardware import Camera

    cam = Camera()
    if not cam.initialize():
        print("✗ Camera failed")
        return

    client = NVIDIAClient()
    print("  Capturing frame...")
    img_b64 = cam.capture_base64()
    cam.shutdown()

    if img_b64:
        print(f"  Frame: {len(img_b64)} chars base64")
        print("  Querying vision model...")
        resp = await client.vision_chat(
            text="Identify what you see in this image.",
            image_base64=img_b64,
        )
        print(f"  Response: {resp.content[:200]}...")
        print(f"  Latency: {resp.latency_ms}ms")
    else:
        print("✗ No image captured")

    await client.close()
    print()


async def test_nvidia_asr():
    print("=== Testing NVIDIA ASR (USB Mic) ===")
    from servo_skull.services import NVIDIAClient
    from servo_skull.hardware import AudioRecorder

    rec = AudioRecorder()
    print("  Recording 3 seconds... (speak now)")
    if rec.start():
        await asyncio.sleep(3)
        wav = rec.stop()
        rec.shutdown()
        if wav:
            client = NVIDIAClient()
            print("  Transcribing...")
            result = await client.transcribe(wav)
            print(f"  Text: '{result.text}'")
            print(f"  Latency: {result.duration_ms}ms")
            await client.close()
        else:
            print("✗ No audio recorded")
    else:
        print("✗ Failed to start recording")
    print()


async def test_personality():
    print("=== Testing Personality System ===")
    from servo_skull.personality import ConversationContext
    ctx = ConversationContext()
    prompt = ctx.load_system_prompt()
    print(f"✓ System prompt loaded ({len(prompt)} chars)")
    ctx.add_user_message("Identify target")
    ctx.add_assistant_message("SCANNING. Target identified: Heretek data-pattern. PURGE.")
    messages = ctx.get_messages()
    print(f"  Message count: {len(messages)}")
    print("✓ Personality context working\n")


async def test_full_pipeline():
    print("=== Testing Full Pipeline ===")
    from servo_skull.hardware import AudioRecorder, Camera
    from servo_skull.services import NVIDIAClient, PiperService
    from servo_skull.personality import ConversationContext

    # Record
    rec = AudioRecorder()
    print("  Recording 3 seconds... (say something)")
    if not rec.start():
        print("✗ Recorder failed")
        return
    await asyncio.sleep(3)
    wav = rec.stop()
    rec.shutdown()
    if not wav:
        print("✗ No audio")
        return
    print(f"  Recorded: {len(wav)} bytes")

    # ASR
    client = NVIDIAClient()
    print("  Transcribing...")
    asr_result = await client.transcribe(wav)
    user_text = asr_result.text.strip()
    print(f"  Text: '{user_text}'")
    if not user_text:
        await client.close()
        return

    # Vision
    cam = Camera()
    img_b64 = None
    if cam.initialize():
        img_b64 = cam.capture_base64()
        cam.shutdown()

    # LLM
    print("  Querying LLM...")
    if img_b64:
        resp = await client.vision_chat(text=user_text, image_base64=img_b64)
    else:
        resp = await client.chat_completion([{"role": "user", "content": user_text}])
    print(f"  Response: {resp.content[:200]}...")

    # TTS
    piper = PiperService()
    if piper.check_model():
        print("  Speaking response...")
        await piper.speak_stream(resp.content)
        print("  ✓ Spoken")
    else:
        print("  ✗ Piper model missing")

    await client.close()
    print()


async def main():
    print("╔══════════════════════════════════════════════════════════╗")
    print("║     SERVO-SKULL THETA-7 — ZERO 2W USB COMPONENT TESTS    ║")
    print("╚══════════════════════════════════════════════════════════╝\n")

    tests = [
        ("Config", test_config),
        ("List Devices", list_devices),
        ("USB Camera", test_camera),
        ("LED Ring", test_light),
        ("USB Microphone", test_audio_recorder),
        ("Piper TTS", test_piper),
        ("NVIDIA Chat", test_nvidia),
        ("NVIDIA Vision", test_nvidia_vision),
        ("NVIDIA ASR", test_nvidia_asr),
        ("Personality", test_personality),
        ("Full Pipeline", test_full_pipeline),
    ]

    for name, test_func in tests:
        try:
            await test_func()
        except Exception as e:
            print(f"✗ {name} test failed: {e}\n")

    print("═══════════════════════════════════════════════════════════")
    print("All tests complete. Check output above for any failures.")
    print("═══════════════════════════════════════════════════════════")


if __name__ == "__main__":
    asyncio.run(main())