# Servo-Skull Theta-7 — Zero 2W USB Edition

> *"The flesh is weak. The machine is eternal. This unit serves the Omnissiah."*

**Fully free tier**: NVIDIA API (build.nvidia.com) + Local Piper TTS  
**Hardware**: Raspberry Pi Zero 2W + **USB Webcam** + **USB Microphone** + **USB Hub** + WS2812B + Button + MAX98357A

---

## Hardware Bill of Materials

| Component | Model | Qty | Est. Cost |
|-----------|-------|-----|-----------|
| **SBC** | Raspberry Pi Zero 2W | 1 | $15 |
| **Camera** | USB Webcam (UVC, 720p+) — Logitech C270/C920, generic | 1 | $15-30 |
| **Microphone** | USB Mic — Blue Snowball, Fifine, generic USB mic | 1 | $15-25 |
| **USB Hub** | Powered USB 2.0 Hub (4-port) — **Required** for Zero 2W | 1 | $8-15 |
| **Speaker** | MAX98357A I²S Amp + 3W 4Ω Speaker | 1 | $10 |
| **Light** | WS2812B LED Ring (12 LED) + 74AHCT125 level shifter | 1 | $8 |
| **Button** | Arcade Push Button (illuminated) | 1 | $5 |
| **Power** | 5V 3A USB-C Supply (for Pi + hub) | 1 | $10 |
| **Misc** | Micro USB OTG cable, JST cables, DuPont wires, heat shrink | — | $10 |

**Total: ~$96-128** — **Zero monthly cost**

> **⚠️ Powered Hub Required**: Zero 2W has one USB OTG port (max 500mA). A powered hub provides stable power for webcam + mic simultaneously.

---

## Wiring Diagram (Zero 2W 40-pin GPIO)

```
Zero 2W GPIO (same pinout as Pi 5)
┌─────────────────────────────────────────────────────────────┐
│  3V3  (1)  (2)  5V                                          │
│  GPIO2  (3)  (4)  5V                                        │
│  GPIO3  (5)  (6)  GND                                       │
│  GPIO4  (7)  (8)  GPIO14                                    │
│  GND    (9)  (10) GPIO15                                    │
│  GPIO17 (11) (12) GPIO18  ← WS2812B DATA (via level shifter)│
│  GPIO27 (13) (14) GND                                       │
│  GPIO22 (15) (16) GPIO23                                    │
│  3V3   (17)  (18) GPIO24                                    │
│  GPIO10 (19) (20) GND                                       │
│  GPIO9  (21) (22) GPIO25                                    │
│  GPIO11 (23) (24) GPIO8                                     │
│  GND   (25)  (26) GPIO7                                     │
│  GPIO0  (27) (28) GPIO1                                     │
│  GPIO5  (29) (30) GND                                       │
│  GPIO6  (31) (32) GPIO12  ← PWM0 (Servo, optional)          │
│  GPIO13 (33) (34) GND                                       │
│  GPIO19 (35) (36) GPIO16  ← I2S BCK (MAX98357A)             │
│  GPIO26 (37) (38) GPIO20  ← I2S WS  (MAX98357A)             │
│  GND   (39)  (40) GPIO21  ← I2S DATA (MAX98357A)            │
└─────────────────────────────────────────────────────────────┘

Connections:
• Button:       GPIO17 (Pin 11) → Button → GND (Pin 14) [internal pull-up]
• Button LED:   GPIO27 (Pin 13) → LED Anode → 220Ω → GND
• WS2812B:      GPIO18 (Pin 12) → 74AHCT125 (3.3V→5V) → DIN
                5V (Pin 2/4) → WS2812B VCC | GND → GND
• I²S Audio:    BCK=GPIO19 (Pin 35), WS=GPIO20 (Pin 38), DATA=GPIO21 (Pin 40) → MAX98357A
• USB Devices:  USB OTG (micro USB) → Powered Hub → Webcam + USB Mic
                (Use OTG adapter: micro USB male → USB-A female)
```

> **⚠️ Level Shifter Required**: Zero 2W GPIO is 3.3V, WS2812B needs 5V logic. Use 74AHCT125 or bi-directional level converter. Power LED ring from 5V pins (2/4), not 3.3V.

---

## Software Setup (Zero 2W USB)

### 1. Flash Raspberry Pi OS
```bash
# Raspberry Pi Imager
# OS: Raspberry Pi OS Lite (64-bit) Bookworm
# Customize: hostname=servo-skull, username=pi, password=***
# Enable: SSH, WiFi, locale/timezone
```

### 2. First Boot & Config
```bash
ssh pi@servo-skull.local

# Enable interfaces
sudo raspi-config nonint do_i2c 0
sudo raspi-config nonint do_spi 0

# Enable I2S audio for MAX98357A
echo "dtparam=i2s=on" | sudo tee -a /boot/firmware/config.txt
echo "dtoverlay=hifiberry-dac" | sudo tee -a /boot/firmware/config.txt

# USB webcam/mic work out of the box (UVC/UAC)
sudo reboot
```

### 3. Verify USB Devices
```bash
# List cameras
v4l2-ctl --list-devices
# Should show: /dev/video0  (your webcam)

# List audio devices
arecord -l    # Input (mic)
aplay -l      # Output (speaker/MAX98357A)
# Note the card/device numbers, e.g., "card 1: Device [USB Audio Device], device 0"

# Test camera
ffmpeg -f v4l2 -i /dev/video0 -frames 1 test.jpg
# Test mic
arecord -D plughw:1,0 -f cd -t wav -d 3 test.wav && aplay test.wav
```

### 4. Install System Dependencies
```bash
sudo apt update && sudo apt install -y \
  python3-venv python3-pip \
  python3-rpi-ws281x \
  libopenblas-dev libatlas-base-dev \
  portaudio19-dev libasound2-dev \
  v4l-utils ffmpeg \
  git
```

### 5. Clone & Setup Project
```bash
git clone <your-repo> ~/servo-skull
cd ~/servo-skull

python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
```

### 6. Download Piper Model (British/Imperial accent)
```bash
mkdir -p models
cd models
piper --model en_GB-alba-medium --download-dir .
cd ..
# Verify:
ls models/en_GB-alba-medium.onnx*
```

### 7. Get NVIDIA API Key (FREE)
1. Go to **https://build.nvidia.com**
2. Sign in (no credit card needed)
3. Generate API key
4. Copy key (format: `nvapi-xxxxxxxxxxxxxxxxxxxxxxxx`)

### 8. Configure Environment
```bash
cp .env.example .env
nano .env
# Paste your NVIDIA_API_KEY
```

### 9. Update Config for Your Devices
```bash
nano config.yaml
# Update these if your devices differ:
hardware:
  camera_device: "/dev/video0"       # From v4l2-ctl --list-devices
  audio_input_device: "default"      # Or "hw:1,0" from arecord -l
  audio_output_device: "default"     # Or "hw:0,0" from aplay -l
```

---

## Running

### Test Components First
```bash
cd ~/servo-skull
source .venv/bin/activate
python test_components.py
# Run all tests or comment out specific ones
```

### Manual Run
```bash
python -m servo_skull.main
```

### Systemd Service (Auto-start)
```bash
sudo cp systemd/servo-skull.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now servo-skull

# Check logs
sudo journalctl -u servo-skull -f
```

---

## Usage

1. **Press and hold** the illuminated button
2. **Speak** your query (max 20 seconds on Zero 2W)
3. **Release** → Skull processes:
   - USB Mic → NVIDIA Canary ASR (free)
   - USB Webcam → NVIDIA Llama-3.2-Vision (free)
   - Both → NVIDIA Llama-3.1-70B with 40k prompt (free)
   - Response → Local Piper TTS (free, offline, Imperial accent)
4. **Listen** to the Machine Spirit

### Example Commands
- *"Status report"* — Sensor status + system health
- *"Identify target"* — Vision analysis
- *"Recite the Litany of the Machine God"* — Theological response
- *"Scan for heretical tech"* — Humorous scan
- *"Who is the Emperor?"* — Lore response

---

## NVIDIA Free Tier Limits

| Endpoint | Model | Free Tier |
|----------|-------|-----------|
| Chat | `meta/llama-3.1-70b-instruct` | 1000 req/day |
| Vision | `meta/llama-3.2-90b-vision-instruct` | 1000 req/day |
| ASR | `nvidia/canary-1b` | 1000 req/day |

**Shared quota**: 1000 total requests/day across all endpoints.  
Plenty for servo-skull use (~50-100 interactions/day).

---

## Configuration (config.yaml)

```yaml
hardware:
  camera_device: "/dev/video0"       # USB webcam
  camera_width: 640
  camera_height: 480
  camera_fps: 15
  camera_fourcc: "MJPG"              # MJPG for lower CPU, YUYV for compatibility

  audio_input_device: "default"      # USB mic (or "hw:1,0")
  audio_output_device: "default"     # MAX98357A (or "hw:0,0")
  sample_rate: 16000
  max_record_seconds: 20

  led_count: 12
  led_brightness: 100
```

---

## Zero 2W USB Optimizations

| Optimization | Setting | Why |
|--------------|---------|-----|
| **MJPG camera** | `camera_fourcc: "MJPG"` | Hardware JPEG encode = less CPU |
| **Lower res** | 640x480 | Faster JPEG, smaller upload |
| **Fewer LEDs** | 12 vs 16 | <200mA on 5V rail |
| **Shorter recording** | 20s max | Less RAM for audio buffer |
| **Less history** | 4 turns | Smaller context = faster LLM |

---

## Troubleshooting

| Issue | Solution |
|-------|----------|
| **"NVIDIA API unreachable"** | Check WiFi: `ping 8.8.8.8`; verify API key in `.env` |
| **Piper model not found** | `cd models && piper --model en_GB-alba-medium --download-dir .` |
| **No audio output** | `speaker-test -c2`; check `dtoverlay=hifiberry-dac` in `/boot/firmware/config.txt` |
| **USB mic not detected** | `arecord -l`; check powered hub; try `audio_input_device: "hw:1,0"` in config |
| **Webcam not detected** | `v4l2-ctl --list-devices`; try `camera_device: "/dev/video0"` or `/dev/video2` |
| **Camera failed** | Try `camera_fourcc: "YUYV"`; some cams don't support MJPG |
| **LED ring wrong colors** | Check 74AHCT125 wiring; power from 5V not 3.3V |
| **ImportError: gpiod** | `sudo apt install python3-gpiod` |
| **ImportError: rpi_ws281x** | `sudo apt install python3-rpi-ws281x` |
| **Out of memory** | Reduce `camera_width/height`, `max_record_seconds`, `led_count` |
| **USB bandwidth errors** | Use USB 2.0 hub (not 3.0); lower camera FPS to 10 |

---

## Extending (Post-MVP)

- **Wake word**: Add Porcupine (free tier: 3 keywords) for hands-free
- **Servos**: Pan/tilt tracking with `gpiozero.AngularServo`
- **Local VLM**: Moondream/SmolVLM for offline vision (needs 1GB+ RAM)
- **Multi-skull**: MQTT mesh for coordinated patrols
- **OLED**: SSD1306 for scrolling litanies

---

## License

Hobbyist/educational use. Warhammer 40k IP © Games Workshop.  
NVIDIA API subject to NVIDIA terms. Piper TTS by RHasspy (MIT/Apache-2.0).

---

**FOR THE OMNISSIAH. FOR THE EMPEROR.**