"""
Structured logging for Servo-Skull.
Outputs to console (rich) and rotating file.
"""

import logging
import sys
from pathlib import Path
from logging.handlers import RotatingFileHandler

try:
    from rich.logging import RichHandler
    RICH_AVAILABLE = True
except ImportError:
    RICH_AVAILABLE = False


def setup_logging(level: str = "INFO", log_dir: str = "logs") -> None:
    """Configure application logging."""
    log_path = Path(log_dir)
    log_path.mkdir(exist_ok=True)

    # Root logger
    root = logging.getLogger()
    root.setLevel(getattr(logging, level.upper(), logging.INFO))

    # Clear existing handlers
    root.handlers.clear()

    # Format
    fmt = logging.Formatter(
        "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%H:%M:%S",
    )

    # File handler (rotating)
    file_handler = RotatingFileHandler(
        log_path / "servo_skull.log",
        maxBytes=5_000_000,  # 5MB
        backupCount=3,
        encoding="utf-8",
    )
    file_handler.setFormatter(fmt)
    file_handler.setLevel(logging.DEBUG)
    root.addHandler(file_handler)

    # Console handler
    if RICH_AVAILABLE:
        console_handler = RichHandler(
            rich_tracebacks=True,
            tracebacks_show_locals=False,
            show_time=True,
            show_path=False,
        )
        console_handler.setFormatter(logging.Formatter("%(message)s", datefmt="%H:%M:%S"))
    else:
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setFormatter(fmt)

    console_handler.setLevel(getattr(logging, level.upper(), logging.INFO))
    root.addHandler(console_handler)

    # Suppress noisy third-party loggers
    logging.getLogger("aiohttp").setLevel(logging.WARNING)
    logging.getLogger("asyncio").setLevel(logging.WARNING)
    logging.getLogger("PIL").setLevel(logging.WARNING)

    logging.getLogger("servo_skull").info("Logging initialized")


def get_logger(name: str) -> logging.Logger:
    """Get logger for module."""
    return logging.getLogger(f"servo_skull.{name}")