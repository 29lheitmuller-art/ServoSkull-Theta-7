"""
Servo-Skull Theta-7 Configuration Management
Loads from config.yaml and .env with Pydantic validation.
"""

from pathlib import Path
from typing import Optional
from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class NVIDIAConfig(BaseSettings):
    """NVIDIA API configuration (NIM / build.nvidia.com)."""
    api_key: str = Field(default="", validation_alias="NVIDIA_API_KEY")
    base_url: str = "https://integrate.api.nvidia.com/v1"
    chat_model: str = "meta/llama-3.1-70b-instruct"
    vision_model: str = "meta/llama-3.2-90b-vision-instruct"
    asr_model: str = "nvidia/canary-1b"
    max_tokens: int = 500
    temperature: float = 0.8
    timeout_seconds: int = 30
    max_retries: int = 3

    @field_validator("api_key")
    @classmethod
    def validate_api_key(cls, v: str) -> str:
        if not v or v == "nvapi-your-key-here":
            raise ValueError("NVIDIA_API_KEY must be set in .env (get from https://build.nvidia.com)")
        return v


class PiperConfig(BaseSettings):
    model: str = "en_GB-alba-medium"
    model_dir: str = "models"
    length_scale: float = 1.1
    noise_scale: float = 0.667
    noise_w: float = 0.8
    sample_rate: int = 22050


class HardwareConfig(BaseSettings):
    button_gpio: int = 17
    button_led_gpio: int = 27
    led_strip_gpio: int = 18
    led_count: int = 16
    led_brightness: int = 128
    i2s_bck: int = 19
    i2s_ws: int = 20
    i2s_data: int = 21
    camera_width: int = 1280
    camera_height: int = 720
    camera_fps: int = 15
    sample_rate: int = 16000
    channels: int = 1
    max_record_seconds: int = 30
    audio_device: str = "default"


class ServoSkullConfig(BaseSettings):
    name: str = "Servo-Skull Theta-7"
    designation: str = "Adeptus Mechanicus / Ordo Hereticus"
    personality: str = "loyal, laconic, tech-priest vernacular"
    mission: str = "Surveillance and data acquisition"
    conversation_history_limit: int = 6


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        env_nested_delimiter="__",
        extra="ignore",
    )

    nvidia: NVIDIAConfig = Field(default_factory=NVIDIAConfig)
    piper: PiperConfig = Field(default_factory=PiperConfig)
    hardware: HardwareConfig = Field(default_factory=HardwareConfig)
    servo_skull: ServoSkullConfig = Field(default_factory=ServoSkullConfig)

    @classmethod
    def from_yaml(cls, path: str | Path = "config.yaml") -> "Settings":
        import yaml
        with open(path) as f:
            data = yaml.safe_load(f) or {}
        return cls(**data)


# Global settings instance
settings: Optional[Settings] = None


def load_settings(config_path: str | Path = "config.yaml") -> Settings:
    global settings
    settings = Settings.from_yaml(config_path)
    return settings


def get_settings() -> Settings:
    if settings is None:
        return load_settings()
    return settings