"""
NVIDIA API Client for Servo-Skull Cogitator (Zero 2W Optimized)
Uses NVIDIA free tier: 1000 req/day for chat, vision, and ASR.
Models: Llama-3.1-70B, Llama-3.2-90B-Vision, Canary-1B ASR
"""

import asyncio
import logging
import time
from dataclasses import dataclass
from typing import Optional

import aiohttp

from servo_skull.config import get_settings

logger = logging.getLogger(__name__)


@dataclass
class ChatResponse:
    content: str
    model: str
    usage: dict
    latency_ms: int


@dataclass
class TranscriptionResponse:
    text: str
    language: str
    duration_ms: int


class NVIDIAClient:
    """
    Async client for NVIDIA API (build.nvidia.com free tier).
    Handles chat, vision, and Whisper transcription.
    """

    def __init__(self):
        self.settings = get_settings().nvidia
        self._session: Optional[aiohttp.ClientSession] = None

        self.base_url = self.settings.base_url
        self.api_key = self.settings.api_key

        self._base_headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

        self.chat_model = self.settings.chat_model
        self.vision_model = self.settings.vision_model
        self.asr_model = self.settings.asr_model

    async def _get_session(self) -> aiohttp.ClientSession:
        """Get or create aiohttp session with connection pooling."""
        if self._session is None or self._session.closed:
            # Zero 2W: limit connections to save memory
            connector = aiohttp.TCPConnector(limit=2, limit_per_host=2)
            timeout = aiohttp.ClientTimeout(total=self.settings.timeout_seconds)
            self._session = aiohttp.ClientSession(
                timeout=timeout,
                headers=self._base_headers,
                connector=connector,
            )
        return self._session

    async def close(self) -> None:
        """Close HTTP session and connector."""
        if self._session and not self._session.closed:
            await self._session.close()
            if self._session.connector:
                await self._session.connector.close()

    async def _request_with_retry(
        self,
        method: str,
        url: str,
        **kwargs
    ) -> dict:
        """Make request with exponential backoff retry."""
        last_error = None
        for attempt in range(self.settings.max_retries):
            try:
                session = await self._get_session()
                async with session.request(method, url, **kwargs) as resp:
                    if resp.status == 429:  # Rate limited
                        wait = min(2 ** attempt, 10)
                        logger.warning(f"Rate limited, waiting {wait}s (attempt {attempt + 1})")
                        await asyncio.sleep(wait)
                        continue
                    if resp.status >= 500:
                        wait = 2 ** attempt
                        logger.warning(f"Server error {resp.status}, retrying in {wait}s...")
                        await asyncio.sleep(wait)
                        continue
                    resp.raise_for_status()
                    return await resp.json()
            except aiohttp.ClientError as e:
                last_error = e
                wait = 2 ** attempt
                logger.warning(f"Request failed: {e}, retrying in {wait}s...")
                await asyncio.sleep(wait)
            except asyncio.TimeoutError:
                last_error = "Timeout"
                logger.warning(f"Request timeout, retrying...")
                await asyncio.sleep(2 ** attempt)

        raise Exception(f"NVIDIA API request failed after {self.settings.max_retries} retries: {last_error}")

    async def chat_completion(
        self,
        messages: list[dict],
        model: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
    ) -> ChatResponse:
        """
        Send chat completion request (OpenAI-compatible format).
        """
        start = time.time()
        payload = {
            "model": model or self.chat_model,
            "messages": messages,
            "temperature": temperature if temperature is not None else self.settings.temperature,
            "max_tokens": max_tokens or self.settings.max_tokens,
            "stream": False,
        }

        url = f"{self.base_url}/chat/completions"
        logger.debug(f"NVIDIA chat: {payload['model']}, {len(messages)} msgs")

        data = await self._request_with_retry("POST", url, json=payload)

        latency = int((time.time() - start) * 1000)
        choice = data["choices"][0]
        content = choice["message"]["content"]
        usage = data.get("usage", {})

        logger.info(f"Chat response: {latency}ms, {usage.get('total_tokens', 0)} tokens")
        return ChatResponse(
            content=content,
            model=data.get("model", payload["model"]),
            usage=usage,
            latency_ms=latency,
        )

    async def transcribe(
        self,
        audio_bytes: bytes,
        filename: str = "audio.wav",
        language: Optional[str] = None,
    ) -> TranscriptionResponse:
        """
        Transcribe audio using NVIDIA Canary/Parakeet ASR.
        """
        start = time.time()

        data = aiohttp.FormData()
        data.add_field("file", audio_bytes, filename=filename, content_type="audio/wav")
        data.add_field("model", self.asr_model)
        if language:
            data.add_field("language", language)

        url = f"{self.base_url}/audio/transcriptions"
        logger.debug(f"ASR request: {len(audio_bytes)} bytes")

        session = await self._get_session()
        headers = {k: v for k, v in self._base_headers.items() if k != "Content-Type"}

        async with session.post(url, data=data, headers=headers) as resp:
            if resp.status == 429:
                await asyncio.sleep(2)
                async with session.post(url, data=data, headers=headers) as resp2:
                    resp2.raise_for_status()
                    result = await resp2.json()
            else:
                resp.raise_for_status()
                result = await resp.json()

        latency = int((time.time() - start) * 1000)
        text = result.get("text", "").strip()
        lang = result.get("language", language or "en")

        logger.info(f"Transcription: {latency}ms, '{text[:50]}...'")
        return TranscriptionResponse(text=text, language=lang, duration_ms=latency)

    async def vision_chat(
        self,
        text: str,
        image_base64: str,
        model: Optional[str] = None,
        system_prompt: Optional[str] = None,
    ) -> ChatResponse:
        """
        Vision + text chat using Llama-3.2-Vision.
        """
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})

        messages.append({
            "role": "user",
            "content": [
                {"type": "text", "text": text},
                {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{image_base64}"}}
            ]
        })

        return await self.chat_completion(
            messages,
            model=model or self.vision_model,
        )

    async def health_check(self) -> bool:
        """Quick API health check."""
        try:
            session = await self._get_session()
            async with session.get(f"{self.base_url}/models") as resp:
                return resp.status == 200
        except Exception:
            return False


# Convenience function for testing
async def quick_transcribe(audio_bytes: bytes) -> str:
    client = NVIDIAClient()
    try:
        result = await client.transcribe(audio_bytes)
        return result.text
    finally:
        await client.close()