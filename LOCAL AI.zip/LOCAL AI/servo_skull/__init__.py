"""
Servo-Skull Theta-7 — Warhammer 40k AI Servitor
Adeptus Mechanicus pattern servo-skull with voice, vision, and vox-caster.
"""

__version__ = "1.0.0"
__designation__ = "Adeptus Mechanicus / Ordo Hereticus"