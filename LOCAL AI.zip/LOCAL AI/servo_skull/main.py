#!/usr/bin/env python3
"""
Servo-Skull Theta-7 — Zero 2W Main Orchestrator
Free tier: NVIDIA API (chat/vision/ASR) + Local Piper TTS
"""

import asyncio
import logging
import signal
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from servo_skull.config import load_settings, get_settings
from servo_skull.hardware import PushButton, LightRing, Camera, AudioRecorder
from servo_skull.services import NVIDIAClient, PiperService, ChatResponse
from servo_skull.personality import ConversationContext, SensorStatus
from servo_skull.utils.logging import setup_logging


class ServoSkull:
    """
    Zero 2W optimized servo-skull orchestrator.
    Uses NVIDIA free tier API + local Piper TTS.
    """

    def __init__(self):
        self.settings = load_settings()
        self.logger = logging.getLogger("servo_skull")

        # Hardware
        self.button: PushButton | None = None
        self.light: LightRing | None = None
        self.camera: Camera | None = None
        self.recorder: AudioRecorder | None = None

        # Services
        self.nvidia: NVIDIAClient | None = None
        self.piper: PiperService | None = None

        # Personality
        self.context: ConversationContext | None = None
        self.sensor_status = SensorStatus()

        # State
        self._running = False
        self._recording = False
        self._audio_data: bytes | None = None
        self._shutdown_event = asyncio.Event()

    async def initialize(self) -> bool:
        """Initialize all subsystems."""
        self.logger.info("Initializing Servo-Skull Theta-7 (Zero 2W)...")

        # Initialize personality context
        self.context = ConversationContext(
            max_history=self.settings.servo_skull.conversation_history_limit
        )

        # Initialize services
        self.nvidia = NVIDIAClient()
        self.piper = PiperService()

        # Check NVIDIA API health
        self.logger.info("Checking NVIDIA API...")
        if not await self.nvidia.health_check():
            self.logger.warning("NVIDIA API health check failed - continuing anyway")
            self.sensor_status.last_error = "NVIDIA API unreachable"
        else:
            self.logger.info("NVIDIA API OK")

        # Initialize hardware
        try:
            self.light = LightRing()
            self.light.initialize()
            self.sensor_status.light_ok = True
        except Exception as e:
            self.logger.error(f"Light init failed: {e}")
            self.sensor_status.light_ok = False
            self.sensor_status.last_error = f"Light: {e}"

        try:
            self.camera = Camera()
            if self.camera.initialize():
                self.sensor_status.camera_ok = True
            else:
                self.sensor_status.camera_ok = False
                self.sensor_status.last_error = "Camera init failed"
        except Exception as e:
            self.logger.error(f"Camera init failed: {e}")
            self.sensor_status.camera_ok = False
            self.sensor_status.last_error = f"Camera: {e}"

        try:
            self.recorder = AudioRecorder()
            self.recorder.set_level_callback(self._on_audio_level)
            self.sensor_status.microphone_ok = True
        except Exception as e:
            self.logger.error(f"Audio recorder init failed: {e}")
            self.sensor_status.microphone_ok = False
            self.sensor_status.last_error = f"Mic: {e}"

        # Check Piper model
        if not self.piper.check_model():
            self.logger.error("Piper model not found! Run: piper --model en_GB-alba-medium --download-dir models/")
            self.sensor_status.speaker_ok = False
            self.sensor_status.last_error = "Piper model missing"
        else:
            self.sensor_status.speaker_ok = True

        # Initialize button last (starts monitoring)
        try:
            self.button = PushButton(
                on_press=self._on_button_press,
                on_release=self._on_button_release,
            )
            await self.button.initialize()
        except Exception as e:
            self.logger.error(f"Button init failed: {e}")
            self.sensor_status.last_error = f"Button: {e}"

        # Update context with sensor status
        self.context.sensor_status = self.sensor_status

        self.logger.info("Servo-Skull initialization complete")
        self.logger.info(f"Status: {self.context.get_summary()}")

        # Startup announcement
        await self._speak("Rites of activation complete. Servo-Skull Theta-Seven online. The Emperor protects.")
        self.light.set_state(self.light.LightState.IDLE)

        return True

    def _on_audio_level(self, level: float) -> None:
        """Callback for audio level during recording."""
        pass

    def _on_button_press(self) -> None:
        """Button pressed - start recording."""
        if self._recording:
            return

        self._recording = True
        self._audio_data = None
        self.logger.info("Vox recording STARTED")
        self.light.set_state(self.light.LightState.RECORDING)

        if self.recorder and self.recorder.start():
            self.logger.debug("Recorder started")
        else:
            self.logger.error("Failed to start recorder")
            self._recording = False
            self.light.set_state(self.light.LightState.ERROR)

    def _on_button_release(self) -> None:
        """Button released - stop recording and process."""
        if not self._recording:
            return

        self._recording = False
        self.logger.info("Vox recording STOPPED")

        if self.recorder:
            self._audio_data = self.recorder.stop()

        if self._audio_data:
            asyncio.create_task(self._process_voice_command())
        else:
            self.logger.warning("No audio data recorded")
            self.light.set_state(self.light.LightState.IDLE)

    async def _process_voice_command(self) -> None:
        """Process recorded audio: ASR -> Vision -> LLM -> TTS."""
        self.light.set_state(self.light.LightState.THINKING)

        try:
            # 1. Transcribe via NVIDIA ASR (Canary)
            self.logger.info("Transcribing via NVIDIA ASR...")
            transcript_result = await self.nvidia.transcribe(
                self._audio_data,
                language="en",
            )
            user_text = transcript_result.text.strip()

            if not user_text:
                await self._speak("Vox input unclear. Repeat.")
                self.light.set_state(self.light.LightState.IDLE)
                return

            self.logger.info(f"Transcribed: {user_text}")

            # 2. Capture camera frame for vision
            image_b64 = None
            if self.camera and self.camera.is_ready():
                image_b64 = self.camera.capture_base64()
                if image_b64:
                    self.logger.debug(f"Camera frame captured: {len(image_b64)} chars base64")

            # 3. Get LLM response (with vision if image available)
            self.logger.info("Querying NVIDIA LLM...")
            if image_b64:
                response = await self.nvidia.vision_chat(
                    text=user_text,
                    image_base64=image_b64,
                    system_prompt=self.context.load_system_prompt(),
                )
            else:
                messages = self.context.get_messages(current_image_b64=None)
                for i, msg in enumerate(messages):
                    if msg["role"] == "user" and isinstance(msg["content"], str):
                        messages[i]["content"] = user_text
                        break
                else:
                    messages.append({"role": "user", "content": user_text})

                response = await self.nvidia.chat_completion(messages)

            skull_response = response.content.strip()
            self.logger.info(f"LLM response: {skull_response[:100]}...")

            # 4. Update conversation context
            self.context.add_user_message(user_text, has_image=image_b64 is not None)
            self.context.add_assistant_message(skull_response)

            # 5. Speak response via local Piper TTS
            self.light.set_state(self.light.LightState.SPEAKING)
            await self._speak(skull_response, sync_light=True)

        except Exception as e:
            self.logger.error(f"Voice command processing failed: {e}")
            self.sensor_status.last_error = str(e)
            await self._speak("Cogitator error. Rites of repair required.")
            self.light.set_state(self.light.LightState.ERROR)
            await asyncio.sleep(2)

        finally:
            self.light.set_state(self.light.LightState.IDLE)
            self._audio_data = None

    async def _speak(self, text: str, sync_light: bool = False) -> bool:
        """Speak text via Piper TTS with optional light sync."""
        if not self.piper:
            return False

        def level_cb(level: float):
            if sync_light and self.light:
                pass  # Light animation handles speaking state

        return await self.piper.speak_stream(text, level_callback=level_cb)

    async def run(self) -> None:
        """Main run loop with WiFi monitoring."""
        self._running = True
        self.logger.info("Servo-Skull main loop started")

        wifi_check_interval = 60  # seconds
        last_wifi_check = 0

        try:
            while self._running:
                await asyncio.sleep(1)

                # Periodic WiFi check (Zero 2W can drop connection)
                now = time.time()
                if now - last_wifi_check > wifi_check_interval:
                    last_wifi_check = now
                    if self.nvidia and not await self.nvidia.health_check():
                        self.logger.warning("WiFi/API connection lost, will retry on next request")
                        self.sensor_status.wifi_connected = False
                        self.sensor_status.last_error = "Warp link severed"
                    else:
                        self.sensor_status.wifi_connected = True

                # Check for max recording duration
                if self._recording and self.recorder and self.recorder.is_max_duration_reached():
                    self.logger.warning("Max recording duration reached")
                    self._on_button_release()

        except asyncio.CancelledError:
            self.logger.info("Main loop cancelled")
        except Exception as e:
            self.logger.error(f"Main loop error: {e}")
        finally:
            await self.shutdown()

    async def shutdown(self) -> None:
        """Graceful shutdown."""
        self.logger.info("Initiating shutdown rites...")
        self._running = False

        if self.light:
            await self.light.shutdown()

        if self.button:
            await self.button.shutdown()
        if self.camera:
            self.camera.shutdown()
        if self.recorder:
            self.recorder.shutdown()

        if self.nvidia:
            await self.nvidia.close()

        await self._speak("Rites of deactivation complete. The Emperor protects.")
        await asyncio.sleep(1)

        self.logger.info("Servo-Skull shut down complete")


async def main():
    """Entry point."""
    setup_logging()
    logger = logging.getLogger("servo_skull")

    skull = ServoSkull()

    loop = asyncio.get_running_loop()
    shutdown_event = asyncio.Event()

    def signal_handler():
        logger.info("Shutdown signal received")
        shutdown_event.set()

    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, signal_handler)
        except NotImplementedError:
            pass

    if not await skull.initialize():
        logger.error("Initialization failed")
        return 1

    try:
        await asyncio.wait_for(shutdown_event.wait(), timeout=None)
    except asyncio.TimeoutError:
        pass

    await skull.shutdown()
    return 0


if __name__ == "__main__":
    try:
        exit_code = asyncio.run(main())
        sys.exit(exit_code)
    except KeyboardInterrupt:
        print("\nInterrupted")
        sys.exit(130)