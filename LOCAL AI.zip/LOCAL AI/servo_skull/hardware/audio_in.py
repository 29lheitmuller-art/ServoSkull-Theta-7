"""
USB Audio Recording for Servo-Skull Vox Input
Uses sounddevice for USB microphone capture.
"""

import asyncio
import logging
import wave
import io
import time
from dataclasses import dataclass
from typing import Optional, Callable

import numpy as np

from servo_skull.config import get_settings

logger = logging.getLogger(__name__)

# Try to import sounddevice
try:
    import sounddevice as sd
    SOUNDDEVICE_AVAILABLE = True
except ImportError:
    SOUNDDEVICE_AVAILABLE = False
    logger.warning("sounddevice not available — running in SIMULATION MODE")


@dataclass
class AudioConfig:
    sample_rate: int = 16000
    channels: int = 1
    dtype: str = "int16"
    device: Optional[str] = None      # Device name or index (None = default)
    max_duration: float = 30.0


class AudioRecorder:
    """
    Push-to-talk audio recorder for USB microphone.
    Records WAV audio at 16kHz mono for Whisper API.
    """

    def __init__(self, config: Optional[AudioConfig] = None):
        self.settings = get_settings()
        self.config = config or AudioConfig(
            sample_rate=self.settings.hardware.sample_rate,
            channels=self.settings.hardware.channels,
            device=self.settings.hardware.audio_input_device,
            max_duration=self.settings.hardware.max_record_seconds,
        )

        self._recording = False
        self._audio_buffer: list[np.ndarray] = []
        self._stream: Optional["sd.InputStream"] = None
        self._start_time = 0.0
        self._level_callback: Optional[Callable[[float], None]] = None

    def set_level_callback(self, callback: Callable[[float], None]) -> None:
        """Set callback for audio level (0.0-1.0) for visual feedback."""
        self._level_callback = callback

    def start(self) -> bool:
        """Start recording. Returns True on success."""
        if self._recording:
            logger.warning("Already recording")
            return False

        if SOUNDDEVICE_AVAILABLE:
            return self._start_real()
        else:
            logger.info("Audio recording started (SIMULATION)")
            self._recording = True
            self._audio_buffer = []
            self._start_time = time.time()
            return True

    def _start_real(self) -> bool:
        """Start real audio capture from USB device."""
        try:
            self._audio_buffer = []
            self._start_time = time.time()

            def callback(indata, frames, time_info, status):
                if status:
                    logger.warning(f"Audio callback status: {status}")
                self._audio_buffer.append(indata.copy())
                if self._level_callback:
                    # Calculate RMS level
                    rms = np.sqrt(np.mean(indata.astype(np.float32) ** 2))
                    # Normalize to 0-1 (assuming 16-bit)
                    level = min(1.0, rms / 32768.0 * 10)
                    self._level_callback(level)

            # Resolve device
            device = self._resolve_device(self.config.device, "input")
            logger.info(f"Starting recording on device: {device}")

            self._stream = sd.InputStream(
                samplerate=self.config.sample_rate,
                channels=self.config.channels,
                dtype=self.config.dtype,
                device=device,
                callback=callback,
                blocksize=1024,
            )
            self._stream.start()
            self._recording = True
            logger.info(f"Recording started: {self.config.sample_rate}Hz, {self.config.channels}ch")
            return True
        except Exception as e:
            logger.error(f"Failed to start recording: {e}")
            return False

    def _resolve_device(self, device_spec: Optional[str], kind: str) -> Optional[int]:
        """Resolve device name to index."""
        if not SOUNDDEVICE_AVAILABLE or device_spec is None or device_spec == "default":
            return None

        # If it's already a number, use it
        try:
            return int(device_spec)
        except ValueError:
            pass

        # Search by name
        devices = sd.query_devices()
        for idx, dev in enumerate(devices):
            if device_spec.lower() in dev["name"].lower():
                if kind == "input" and dev["max_input_channels"] > 0:
                    logger.info(f"Found {kind} device {idx}: {dev['name']}")
                    return idx
                elif kind == "output" and dev["max_output_channels"] > 0:
                    logger.info(f"Found {kind} device {idx}: {dev['name']}")
                    return idx
        logger.warning(f"Device '{device_spec}' not found, using default")
        return None

    def stop(self) -> Optional[bytes]:
        """
        Stop recording and return WAV bytes.
        Returns None if not recording or on error.
        """
        if not self._recording:
            return None

        if SOUNDDEVICE_AVAILABLE and self._stream:
            return self._stop_real()
        else:
            return self._stop_simulated()

    def _stop_real(self) -> Optional[bytes]:
        """Stop real recording and return WAV."""
        try:
            self._stream.stop()
            self._stream.close()
            self._stream = None
            self._recording = False

            if not self._audio_buffer:
                logger.warning("No audio data recorded")
                return None

            # Concatenate all chunks
            audio_data = np.concatenate(self._audio_buffer, axis=0)
            duration = len(audio_data) / self.config.sample_rate
            logger.info(f"Recording stopped: {duration:.2f}s, {len(audio_data)} samples")

            return self._to_wav(audio_data)
        except Exception as e:
            logger.error(f"Failed to stop recording: {e}")
            self._recording = False
            return None

    def _stop_simulated(self) -> bytes:
        """Generate simulated WAV for testing."""
        self._recording = False
        duration = time.time() - self._start_time
        samples = int(duration * self.config.sample_rate)
        audio_data = np.zeros((samples, self.config.channels), dtype=np.int16)
        logger.info(f"Simulated recording stopped: {duration:.2f}s")
        return self._to_wav(audio_data)

    def _to_wav(self, audio_data: np.ndarray) -> bytes:
        """Convert numpy array to WAV bytes."""
        buf = io.BytesIO()
        with wave.open(buf, "wb") as wf:
            wf.setnchannels(self.config.channels)
            wf.setsampwidth(2)  # 16-bit = 2 bytes
            wf.setframerate(self.config.sample_rate)
            wf.writeframes(audio_data.tobytes())
        return buf.getvalue()

    def is_recording(self) -> bool:
        """Check if currently recording."""
        return self._recording

    def get_duration(self) -> float:
        """Get current recording duration in seconds."""
        if self._recording:
            return time.time() - self._start_time
        return 0.0

    def is_max_duration_reached(self) -> bool:
        """Check if max duration reached."""
        return self.get_duration() >= self.config.max_duration

    def shutdown(self) -> None:
        """Clean up resources."""
        if self._recording:
            self.stop()
        logger.info("Audio recorder shut down")


# List available audio devices
def list_audio_devices() -> list[dict]:
    """List all audio input/output devices."""
    if not SOUNDDEVICE_AVAILABLE:
        return []
    devices = sd.query_devices()
    result = []
    for idx, dev in enumerate(devices):
        result.append({
            "index": idx,
            "name": dev["name"],
            "input_channels": dev["max_input_channels"],
            "output_channels": dev["max_output_channels"],
            "default_samplerate": dev["default_samplerate"],
        })
    return result