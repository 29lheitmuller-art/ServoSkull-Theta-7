"""
USB Audio Playback for Servo-Skull Vox-Caster
Streams Piper TTS output to USB audio device via sounddevice.
"""

import asyncio
import logging
import subprocess
import tempfile
import os
from pathlib import Path
from typing import Optional, AsyncGenerator

import numpy as np

from servo_skull.config import get_settings

logger = logging.getLogger(__name__)

# Try to import sounddevice for playback
try:
    import sounddevice as sd
    SOUNDDEVICE_AVAILABLE = True
except ImportError:
    SOUNDDEVICE_AVAILABLE = False
    logger.warning("sounddevice not available for playback")


class AudioPlayer:
    """
    Streams Piper TTS audio to USB speaker/headphone via sounddevice.
    """

    def __init__(self):
        self.settings = get_settings()
        self.piper_model = self.settings.piper.model
        self.piper_model_dir = Path(self.settings.piper.model_dir)
        self.sample_rate = self.settings.piper.sample_rate
        self.length_scale = self.settings.piper.length_scale
        self.noise_scale = self.settings.piper.noise_scale
        self.noise_w = self.settings.piper.noise_w

        self._playing = False
        self._process: Optional[subprocess.Popen] = None
        self._output_device = self.settings.hardware.audio_output_device

    def _get_model_path(self) -> Path:
        return self.piper_model_dir / f"{self.piper_model}.onnx"

    def _get_config_path(self) -> Path:
        return self.piper_model_dir / f"{self.piper_model}.onnx.json"

    def check_model(self) -> bool:
        """Verify Piper model files exist."""
        model_path = self._get_model_path()
        config_path = self._get_config_path()
        if not model_path.exists():
            logger.error(f"Piper model not found: {model_path}")
            logger.error("Run: piper --model en_GB-alba-medium --download-dir models/")
            return False
        if not config_path.exists():
            logger.error(f"Piper config not found: {config_path}")
            return False
        return True

    def _resolve_output_device(self) -> Optional[int]:
        """Resolve output device name to index."""
        if not SOUNDDEVICE_AVAILABLE or self._output_device is None or self._output_device == "default":
            return None
        try:
            return int(self._output_device)
        except ValueError:
            pass
        devices = sd.query_devices()
        for idx, dev in enumerate(devices):
            if self._output_device.lower() in dev["name"].lower() and dev["max_output_channels"] > 0:
                logger.info(f"Found output device {idx}: {dev['name']}")
                return idx
        logger.warning(f"Output device '{self._output_device}' not found, using default")
        return None

    def synthesize(self, text: str) -> Optional[bytes]:
        """
        Synthesize text to raw PCM audio using Piper CLI.
        Returns raw 16-bit PCM bytes at sample_rate.
        """
        if not self.check_model():
            return None

        cmd = [
            "piper",
            "--model", str(self._get_model_path()),
            "--config", str(self._get_config_path()),
            "--output_raw",
            "--length_scale", str(self.length_scale),
            "--noise_scale", str(self.noise_scale),
            "--noise_w", str(self.noise_w),
        ]

        try:
            logger.debug(f"Synthesizing: {text[:50]}...")
            result = subprocess.run(
                cmd,
                input=text.encode("utf-8"),
                capture_output=True,
                timeout=15,
            )
            if result.returncode != 0:
                logger.error(f"Piper error: {result.stderr.decode()}")
                return None
            return result.stdout
        except subprocess.TimeoutExpired:
            logger.error("Piper synthesis timed out")
            return None
        except FileNotFoundError:
            logger.error("Piper not installed. Install: pip install piper-tts")
            return None
        except Exception as e:
            logger.error(f"Piper synthesis failed: {e}")
            return None

    async def synthesize_stream(self, text: str) -> AsyncGenerator[bytes, None]:
        """Stream synthesized audio in chunks."""
        if not self.check_model():
            return

        cmd = [
            "piper",
            "--model", str(self._get_model_path()),
            "--config", str(self._get_config_path()),
            "--output_raw",
            "--length_scale", str(self.length_scale),
            "--noise_scale", str(self.noise_scale),
            "--noise_w", str(self.noise_w),
        ]

        try:
            self._process = await asyncio.create_subprocess_exec(
                *cmd,
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            self._process.stdin.write(text.encode("utf-8"))
            await self._process.stdin.drain()
            self._process.stdin.close()

            chunk_size = 4096
            self._playing = True
            while self._playing:
                chunk = await self._process.stdout.read(chunk_size)
                if not chunk:
                    break
                yield chunk
            await self._process.wait()
            self._playing = False
        except Exception as e:
            logger.error(f"Piper streaming failed: {e}")
        finally:
            if self._process:
                try:
                    self._process.stdout.close()
                except Exception:
                    pass
                try:
                    self._process.stderr.close()
                except Exception:
                    pass
                self._process = None

    def play_pcm(self, pcm_data: bytes, blocking: bool = True) -> bool:
        """Play raw PCM audio through sounddevice to USB device."""
        if not SOUNDDEVICE_AVAILABLE:
            logger.warning("sounddevice not available - cannot play audio")
            return False

        try:
            audio = np.frombuffer(pcm_data, dtype=np.int16)
            if audio.ndim == 1:
                audio = audio.reshape(-1, 1)

            device = self._resolve_output_device()
            self._playing = True
            sd.play(audio, samplerate=self.sample_rate, device=device, blocking=blocking)
            self._playing = False
            return True
        except Exception as e:
            logger.error(f"Playback failed: {e}")
            self._playing = False
            return False

    async def speak(self, text: str) -> bool:
        """Synthesize and play text in one call."""
        pcm = self.synthesize(text)
        if pcm:
            return self.play_pcm(pcm)
        return False

    async def speak_stream(
        self,
        text: str,
        level_callback: Optional[callable] = None
    ) -> bool:
        """Stream synthesis and playback with optional level callback."""
        if not SOUNDDEVICE_AVAILABLE:
            logger.warning("Streaming playback requires sounddevice")
            return await self.speak(text)

        try:
            cmd = [
                "piper",
                "--model", str(self._get_model_path()),
                "--config", str(self._get_config_path()),
                "--output_raw",
                "--length_scale", str(self.length_scale),
                "--noise_scale", str(self.noise_scale),
                "--noise_w", str(self.noise_w),
            ]

            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            process.stdin.write(text.encode("utf-8"))
            await process.stdin.drain()
            process.stdin.close()

            self._playing = True
            device = self._resolve_output_device()
            stream = sd.OutputStream(
                samplerate=self.sample_rate,
                channels=1,
                dtype="int16",
                blocksize=1024,
                device=device,
            )
            stream.start()

            while True:
                chunk = await process.stdout.read(2048)
                if not chunk:
                    break
                stream.write(np.frombuffer(chunk, dtype=np.int16).reshape(-1, 1))
                if level_callback:
                    rms = np.sqrt(np.mean(np.frombuffer(chunk, dtype=np.int16).astype(np.float32) ** 2))
                    level = min(1.0, rms / 32768.0 * 5)
                    level_callback(level)

            await process.wait()
            stream.stop()
            stream.close()
            self._playing = False
            return True

        except Exception as e:
            logger.error(f"Streaming speak failed: {e}")
            self._playing = False
            return False

    def stop(self) -> None:
        """Stop current playback."""
        self._playing = False
        if SOUNDDEVICE_AVAILABLE:
            try:
                sd.stop()
            except Exception:
                pass
        if self._process:
            try:
                self._process.terminate()
            except Exception:
                pass

    def is_playing(self) -> bool:
        return self._playing

    def shutdown(self) -> None:
        self.stop()
        logger.info("Audio player shut down")


# List available audio devices for setup
def list_audio_devices() -> list[dict]:
    """List all audio devices."""
    if not SOUNDDEVICE_AVAILABLE:
        return []
    devices = sd.query_devices()
    return [
        {
            "index": idx,
            "name": dev["name"],
            "input_channels": dev["max_input_channels"],
            "output_channels": dev["max_output_channels"],
            "default_samplerate": dev["default_samplerate"],
        }
        for idx, dev in enumerate(devices)
    ]