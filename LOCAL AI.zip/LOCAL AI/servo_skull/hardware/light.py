"""
WS2812B LED Ring Animations for Servo-Skull Status Indication
Uses rpi_ws281x library (install via: sudo apt install python3-rpi-ws281x)
Falls back to simulation mode for development.
"""

import asyncio
import logging
import math
import time
from enum import Enum
from typing import Optional

from servo_skull.config import get_settings

logger = logging.getLogger(__name__)

# Try to import rpi_ws281x
try:
    from rpi_ws281x import Color, PixelStrip, ws
    WS281X_AVAILABLE = True
except ImportError:
    WS281X_AVAILABLE = False
    logger.warning("rpi_ws281x not available — running in SIMULATION MODE")

    # Mock classes for simulation
    class Color:
        def __init__(self, r, g, b):
            self.r, self.g, self.b = r, g, b

    class PixelStrip:
        def __init__(self, *args, **kwargs):
            pass
        def begin(self): pass
        def setPixelColor(self, *args): pass
        def show(self): pass
        def numPixels(self): return 16

    class ws:
        WS2811_STRIP_GRB = 0


class LightState(Enum):
    """Servo-skull light states."""
    IDLE = "idle"              # Slow pulse, teal - awaiting orders
    RECORDING = "recording"    # Fast pulse, red - vox recording
    THINKING = "thinking"      # Rotating scan, amber - cogitating
    SPEAKING = "speaking"      # Waveform sync, white - vox-caster active
    ERROR = "error"            # Flashing red - machine spirit distress
    STARTUP = "startup"        # Sequential green - rites of activation
    SHUTDOWN = "shutdown"      # Fade to black - rites of deactivation


class LightRing:
    """
    WS2812B LED ring controller with predefined animation patterns.

    Hardware: WS2812B data line to GPIO <led_strip_gpio> (PWM capable)
    Power: 5V (level shift 3.3V->5V recommended for reliability)
    """

    # Color definitions (GRB order for WS2812B)
    COLORS = {
        "teal": Color(0, 128, 64),       # Machine spirit
        "red": Color(255, 0, 0),         # Alert/recording
        "amber": Color(255, 128, 0),     # Thinking/cogitating
        "white": Color(255, 255, 255),   # Speaking/vox
        "green": Color(0, 255, 0),       # Success/startup
        "blue": Color(0, 64, 255),       # Data transmission
        "purple": Color(128, 0, 255),    # Warp/psychic
        "off": Color(0, 0, 0),
    }

    def __init__(
        self,
        gpio: Optional[int] = None,
        count: Optional[int] = None,
        brightness: Optional[int] = None,
    ):
        self.settings = get_settings()
        self.gpio = gpio or self.settings.hardware.led_strip_gpio
        self.count = count or self.settings.hardware.led_count
        self.brightness = brightness or self.settings.hardware.led_brightness

        self._strip: Optional[PixelStrip] = None
        self._current_state = LightState.IDLE
        self._animation_task: Optional[asyncio.Task] = None
        self._running = False
        self._frame_delay = 0.05  # 20 FPS animations

    def initialize(self) -> None:
        """Initialize the LED strip."""
        if WS281X_AVAILABLE:
            self._strip = PixelStrip(
                self.count,
                self.gpio,
                800000,  # 800kHz
                10,      # DMA channel
                False,   # invert
                self.brightness,
                0,       # channel
                ws.WS2811_STRIP_GRB,
            )
            self._strip.begin()
            logger.info(f"LED ring initialized: {self.count} LEDs on GPIO {self.gpio}")
        else:
            logger.info("LED ring initialized in SIMULATION MODE")

        self._running = True
        self._animation_task = asyncio.create_task(self._animation_loop())
        self.set_state(LightState.STARTUP)

    def set_state(self, state: LightState) -> None:
        """Change animation state."""
        if state != self._current_state:
            logger.debug(f"Light state: {self._current_state.value} -> {state.value}")
            self._current_state = state

    def set_brightness(self, brightness: int) -> None:
        """Update brightness (0-255)."""
        self.brightness = max(0, min(255, brightness))
        if self._strip:
            self._strip.setBrightness(self.brightness)

    def _set_all(self, color: Color) -> None:
        """Set all LEDs to same color."""
        if self._strip:
            for i in range(self.count):
                self._strip.setPixelColor(i, color)
            self._strip.show()

    def _set_pixel(self, index: int, color: Color) -> None:
        """Set single LED."""
        if self._strip:
            self._strip.setPixelColor(index % self.count, color)

    async def _animation_loop(self) -> None:
        """Main animation loop."""
        frame = 0
        while self._running:
            try:
                await self._render_frame(frame)
                frame += 1
                await asyncio.sleep(self._frame_delay)
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Animation error: {e}")
                await asyncio.sleep(0.1)

    async def _render_frame(self, frame: int) -> None:
        """Render one frame of current animation."""
        state = self._current_state
        n = self.count

        if state == LightState.IDLE:
            self._anim_idle(frame, n)
        elif state == LightState.RECORDING:
            self._anim_recording(frame, n)
        elif state == LightState.THINKING:
            self._anim_thinking(frame, n)
        elif state == LightState.SPEAKING:
            self._anim_speaking(frame, n)
        elif state == LightState.ERROR:
            self._anim_error(frame, n)
        elif state == LightState.STARTUP:
            self._anim_startup(frame, n)
        elif state == LightState.SHUTDOWN:
            self._anim_shutdown(frame, n)

        if self._strip:
            self._strip.show()

    def _anim_idle(self, frame: int, n: int) -> None:
        """Slow breathing pulse - machine spirit dormant."""
        # Slow sine wave: 0.5 Hz
        intensity = (math.sin(frame * 0.06) + 1) * 0.5  # 0-1
        r = int(self.COLORS["teal"].r * intensity * 0.3)
        g = int(self.COLORS["teal"].g * intensity * 0.3)
        b = int(self.COLORS["teal"].b * intensity * 0.3)
        color = Color(r, g, b)
        self._set_all(color)

    def _anim_recording(self, frame: int, n: int) -> None:
        """Fast pulse red - vox recording active."""
        # Fast pulse: 2 Hz
        intensity = (math.sin(frame * 0.25) + 1) * 0.5
        r = int(255 * intensity)
        color = Color(r, 0, 0)
        self._set_all(color)

    def _anim_thinking(self, frame: int, n: int) -> None:
        """Rotating amber scan - cogitator processing."""
        # Single LED rotating at ~60 RPM
        pos = (frame * 2) % n
        self._set_all(self.COLORS["off"])
        # Main LED
        self._set_pixel(pos, self.COLORS["amber"])
        # Trailing ghost LEDs
        for i in range(1, 4):
            fade = 1.0 - (i * 0.25)
            idx = (pos - i) % n
            c = self.COLORS["amber"]
            self._set_pixel(idx, Color(int(c.r * fade), int(c.g * fade), int(c.b * fade)))

    def _anim_speaking(self, frame: int, n: int) -> None:
        """Waveform-style - vox-caster transmitting."""
        # This would ideally sync to audio level
        # For now: symmetric wave from center
        center = n // 2
        for i in range(n):
            dist = abs(i - center)
            # Wave propagating outward
            phase = (frame * 0.3) - (dist * 0.5)
            intensity = max(0, math.sin(phase))
            c = self.COLORS["white"]
            self._set_pixel(i, Color(int(c.r * intensity), int(c.g * intensity), int(c.b * intensity)))

    def _anim_error(self, frame: int, n: int) -> None:
        """Flashing red - critical error."""
        # 3 flashes per second
        if (frame // 7) % 2 == 0:
            self._set_all(self.COLORS["red"])
        else:
            self._set_all(self.COLORS["off"])

    def _anim_startup(self, frame: int, n: int) -> None:
        """Sequential green - rites of activation."""
        progress = min(frame, n * 2)
        leds_on = min(progress // 2, n)
        for i in range(n):
            if i < leds_on:
                self._set_pixel(i, self.COLORS["green"])
            else:
                self._set_pixel(i, self.COLORS["off"])
        if frame > n * 2 + 10:
            self.set_state(LightState.IDLE)

    def _anim_shutdown(self, frame: int, n: int) -> None:
        """Fade to black - rites of deactivation."""
        # Fade all LEDs
        fade = max(0, 1.0 - frame * 0.02)
        for i in range(n):
            c = self._get_pixel_color(i)
            self._set_pixel(i, Color(int(c.r * fade), int(c.g * fade), int(c.b * fade)))
        if fade <= 0:
            self._running = False

    def _get_pixel_color(self, index: int) -> Color:
        """Get current pixel color (simulation only)."""
        return self.COLORS["off"]

    async def flash(self, color_name: str, times: int = 3, duration: float = 0.15) -> None:
        """Quick flash for notifications."""
        color = self.COLORS.get(color_name, self.COLORS["white"])
        prev_state = self._current_state
        for _ in range(times):
            self._set_all(color)
            if self._strip:
                self._strip.show()
            await asyncio.sleep(duration)
            self._set_all(self.COLORS["off"])
            if self._strip:
                self._strip.show()
            await asyncio.sleep(duration)
        self.set_state(prev_state)

    async def shutdown(self) -> None:
        """Clean shutdown with animation."""
        self.set_state(LightState.SHUTDOWN)
        # Wait for shutdown animation
        await asyncio.sleep(1.0)
        self._running = False
        if self._animation_task:
            self._animation_task.cancel()
            try:
                await self._animation_task
            except asyncio.CancelledError:
                pass
        if self._strip:
            self._set_all(self.COLORS["off"])
            self._strip.show()
        logger.info("LED ring shut down")

    # Simulation helpers
    def sim_set_pressed(self, pressed: bool) -> None:
        """For testing: manually trigger recording state."""
        if pressed:
            self.set_state(LightState.RECORDING)
        else:
            self.set_state(LightState.IDLE)