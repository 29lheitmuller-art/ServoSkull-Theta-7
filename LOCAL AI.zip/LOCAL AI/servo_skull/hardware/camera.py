"""
USB Camera Interface for Servo-Skull Auspex (V4L2/OpenCV)
Works with any USB webcam via /dev/videoX.
Falls back to simulation mode for development.
"""

import asyncio
import base64
import io
import logging
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import cv2
import numpy as np

from servo_skull.config import get_settings

logger = logging.getLogger(__name__)


@dataclass
class CameraConfig:
    device: str = "/dev/video0"
    width: int = 640
    height: int = 480
    fps: int = 15
    fourcc: str = "MJPG"        # MJPG or YUYV
    jpeg_quality: int = 85


class Camera:
    """
    USB Camera (V4L2) interface using OpenCV.
    Captures JPEG frames for vision API.
    """

    def __init__(self, config: Optional[CameraConfig] = None):
        self.settings = get_settings()
        self.config = config or CameraConfig(
            device=self.settings.hardware.camera_device,
            width=self.settings.hardware.camera_width,
            height=self.settings.hardware.camera_height,
            fps=self.settings.hardware.camera_fps,
            fourcc=self.settings.hardware.camera_fourcc,
        )
        self._cap: Optional[cv2.VideoCapture] = None
        self._initialized = False
        self._last_frame: Optional[bytes] = None
        self._last_capture_time = 0.0

    def initialize(self) -> bool:
        """Initialize USB camera. Returns True on success."""
        try:
            self._cap = cv2.VideoCapture(self.config.device, cv2.CAP_V4L2)
            if not self._cap.isOpened():
                logger.error(f"Cannot open camera device: {self.config.device}")
                return False

            # Set format
            fourcc = cv2.VideoWriter_fourcc(*self.config.fourcc)
            self._cap.set(cv2.CAP_PROP_FOURCC, fourcc)
            self._cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.config.width)
            self._cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.config.height)
            self._cap.set(cv2.CAP_PROP_FPS, self.config.fps)
            self._cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)  # Low latency

            # Verify settings
            actual_w = int(self._cap.get(cv2.CAP_PROP_FRAME_WIDTH))
            actual_h = int(self._cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
            actual_fps = self._cap.get(cv2.CAP_PROP_FPS)
            logger.info(f"Camera initialized: {actual_w}x{actual_h} @ {actual_fps:.1f}fps (fourcc={self.config.fourcc})")

            # Warm-up: grab a few frames
            for _ in range(3):
                self._cap.grab()
                time.sleep(0.05)

            self._initialized = True
            return True

        except Exception as e:
            logger.error(f"Camera initialization failed: {e}")
            self._initialized = False
            return False

    def capture_jpeg(self) -> Optional[bytes]:
        """Capture a single JPEG frame. Returns bytes or None on failure."""
        if not self._initialized or not self._cap:
            return None

        try:
            # Grab fresh frame
            if not self._cap.grab():
                logger.warning("Camera grab failed")
                return None

            ret, frame = self._cap.retrieve()
            if not ret or frame is None:
                logger.warning("Camera retrieve failed")
                return None

            # Encode to JPEG
            encode_params = [cv2.IMWRITE_JPEG_QUALITY, self.config.jpeg_quality]
            ret, buf = cv2.imencode(".jpg", frame, encode_params)
            if not ret:
                logger.error("JPEG encode failed")
                return None

            jpeg_data = buf.tobytes()
            self._last_frame = jpeg_data
            self._last_capture_time = time.time()
            return jpeg_data

        except Exception as e:
            logger.error(f"Camera capture failed: {e}")
            return None

    def capture_base64(self) -> Optional[str]:
        """Capture and return base64-encoded JPEG for API."""
        jpeg = self.capture_jpeg()
        if jpeg:
            return base64.b64encode(jpeg).decode("utf-8")
        return None

    def save_frame(self, path: str | Path) -> bool:
        """Save last captured frame to file."""
        if self._last_frame:
            Path(path).write_bytes(self._last_frame)
            return True
        return False

    def is_ready(self) -> bool:
        """Check if camera is initialized and ready."""
        return self._initialized and self._cap is not None and self._cap.isOpened()

    def get_stats(self) -> dict:
        """Get camera statistics."""
        return {
            "initialized": self._initialized,
            "device": self.config.device,
            "resolution": f"{self.config.width}x{self.config.height}",
            "fps": self.config.fps,
            "fourcc": self.config.fourcc,
            "last_capture_age": time.time() - self._last_capture_time if self._last_capture_time else None,
        }

    def shutdown(self) -> None:
        """Stop camera and release resources."""
        if self._cap:
            try:
                self._cap.release()
            except Exception as e:
                logger.error(f"Camera shutdown error: {e}")
        self._initialized = False
        logger.info("Camera shut down")


# Convenience function for quick capture
async def quick_capture() -> Optional[str]:
    """Quick one-shot capture for testing."""
    cam = Camera()
    if cam.initialize():
        result = cam.capture_base64()
        cam.shutdown()
        return result
    cam.shutdown()
    return None


# List available cameras
def list_cameras() -> list[dict]:
    """List all V4L2 camera devices."""
    import subprocess
    try:
        result = subprocess.run(["v4l2-ctl", "--list-devices"], capture_output=True, text=True)
        return result.stdout
    except Exception:
        return []