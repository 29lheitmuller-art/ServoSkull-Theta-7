"""
Push-to-Talk Button with LED Feedback
Uses gpiod (modern GPIO interface) for Raspberry Pi.
Falls back to simulation mode for development on non-Pi systems.
"""

import asyncio
import logging
from dataclasses import dataclass
from typing import Callable, Optional

from servo_skull.config import get_settings

logger = logging.getLogger(__name__)

# Try to import gpiod (available on Pi with python3-gpiod)
try:
    import gpiod
    GPIO_AVAILABLE = True
except ImportError:
    GPIO_AVAILABLE = False
    logger.warning("gpiod not available — running in SIMULATION MODE")


@dataclass
class ButtonState:
    """Current button state."""
    pressed: bool = False
    press_time: float = 0.0
    release_time: float = 0.0


class PushButton:
    """
    Push-to-talk button with debouncing and optional LED indicator.

    Hardware connections:
    - Button: GPIO <button_gpio> to GND (active low, pull-up enabled)
    - LED: GPIO <button_led_gpio> to LED anode (cathode to GND via resistor)
    """

    def __init__(
        self,
        button_gpio: Optional[int] = None,
        led_gpio: Optional[int] = None,
        debounce_ms: int = 50,
        on_press: Optional[Callable[[], None]] = None,
        on_release: Optional[Callable[[], None]] = None,
    ):
        self.settings = get_settings()
        self.button_gpio = button_gpio or self.settings.hardware.button_gpio
        self.led_gpio = led_gpio or self.settings.hardware.button_led_gpio
        self.debounce_ms = debounce_ms
        self.on_press = on_press
        self.on_release = on_release

        self._state = ButtonState()
        self._chip: Optional["gpiod.Chip"] = None
        self._button_line: Optional["gpiod.Line"] = None
        self._led_line: Optional["gpiod.Line"] = None
        self._monitor_task: Optional[asyncio.Task] = None
        self._running = False

        # Simulation mode state
        self._sim_pressed = False

    async def initialize(self) -> None:
        """Initialize GPIO lines."""
        if GPIO_AVAILABLE:
            await self._init_gpio()
        else:
            logger.info("Button initialized in SIMULATION MODE")
        self._running = True
        self._monitor_task = asyncio.create_task(self._monitor_loop())
        logger.info(f"Button ready on GPIO {self.button_gpio}")

    async def _init_gpio(self) -> None:
        """Initialize real GPIO using gpiod."""
        self._chip = gpiod.Chip("gpiochip0")

        # Button input with pull-up (active low)
        self._button_line = self._chip.get_line(self.button_gpio)
        self._button_line.request(
            consumer="servo-skull-button",
            type=gpiod.LINE_REQ_DIR_IN,
            flags=gpiod.LINE_REQ_FLAG_BIAS_PULL_UP,
        )

        # LED output
        if self.led_gpio is not None:
            self._led_line = self._chip.get_line(self.led_gpio)
            self._led_line.request(
                consumer="servo-skull-button-led",
                type=gpiod.LINE_REQ_DIR_OUT,
                default_vals=[0],
            )

    async def _monitor_loop(self) -> None:
        """Poll button state with debouncing."""
        last_state = True  # High = not pressed (pull-up)
        stable_count = 0
        required_stable = self.debounce_ms // 10  # 10ms poll interval

        while self._running:
            await asyncio.sleep(0.01)  # 10ms

            if GPIO_AVAILABLE and self._button_line:
                current_state = bool(self._button_line.get_value())
            else:
                current_state = not self._sim_pressed  # Simulated

            if current_state == last_state:
                stable_count += 1
            else:
                stable_count = 0
                last_state = current_state

            if stable_count >= required_stable:
                pressed = not current_state  # Active low
                if pressed != self._state.pressed:
                    await self._handle_transition(pressed)

    async def _handle_transition(self, pressed: bool) -> None:
        """Handle button press/release with callbacks."""
        import time
        now = time.time()

        if pressed:
            self._state.pressed = True
            self._state.press_time = now
            self.set_led(True)
            logger.debug("Button PRESSED")
            if self.on_press:
                try:
                    self.on_press()
                except Exception as e:
                    logger.error(f"on_press callback error: {e}")
        else:
            self._state.pressed = False
            self._state.release_time = now
            self.set_led(False)
            duration = now - self._state.press_time
            logger.debug(f"Button RELEASED (held {duration:.2f}s)")
            if self.on_release:
                try:
                    self.on_release()
                except Exception as e:
                    logger.error(f"on_release callback error: {e}")

    def set_led(self, on: bool) -> None:
        """Control button LED."""
        if GPIO_AVAILABLE and self._led_line:
            self._led_line.set_value(1 if on else 0)
        else:
            logger.debug(f"SIM LED: {'ON' if on else 'OFF'}")

    def is_pressed(self) -> bool:
        """Check current button state."""
        return self._state.pressed

    def get_hold_duration(self) -> float:
        """Get current hold duration in seconds."""
        import time
        if self._state.pressed:
            return time.time() - self._state.press_time
        return 0.0

    async def simulate_press(self, duration: float = 1.0) -> None:
        """Simulate button press (for testing)."""
        if GPIO_AVAILABLE:
            raise RuntimeError("Cannot simulate on real hardware")
        self._sim_pressed = True
        await self._handle_transition(True)
        await asyncio.sleep(duration)
        self._sim_pressed = False
        await self._handle_transition(False)

    async def shutdown(self) -> None:
        """Clean up GPIO resources."""
        self._running = False
        if self._monitor_task:
            self._monitor_task.cancel()
            try:
                await self._monitor_task
            except asyncio.CancelledError:
                pass
        if GPIO_AVAILABLE:
            if self._led_line:
                self._led_line.set_value(0)
                self._led_line.release()
            if self._button_line:
                self._button_line.release()
            if self._chip:
                self._chip.close()
        logger.info("Button shut down")