"""
Conversation context management for Servo-Skull.
Handles system prompt loading, history tracking, and sensor status injection.
"""

from pathlib import Path
from typing import Optional
from dataclasses import dataclass, field
from datetime import datetime

from servo_skull.config import get_settings


@dataclass
class SensorStatus:
    """Current sensor/status readings for context injection."""
    timestamp: datetime = field(default_factory=datetime.now)
    camera_ok: bool = True
    microphone_ok: bool = True
    speaker_ok: bool = True
    light_ok: bool = True
    battery_percent: Optional[float] = None
    cpu_temp_c: Optional[float] = None
    cpu_load_percent: Optional[float] = None
    wifi_connected: bool = True
    last_error: Optional[str] = None

    def to_text(self) -> str:
        """Format as status report for LLM context."""
        lines = ["[SENSOR STATUS]"]
        lines.append(f"  Auspex (Camera): {'NOMINAL' if self.camera_ok else 'MALFUNCTION'}")
        lines.append(f"  Vox (Microphone): {'NOMINAL' if self.microphone_ok else 'MALFUNCTION'}")
        lines.append(f"  Vox-Caster (Speaker): {'NOMINAL' if self.speaker_ok else 'MALFUNCTION'}")
        lines.append(f"  Lumen (Light): {'NOMINAL' if self.light_ok else 'MALFUNCTION'}")
        if self.battery_percent is not None:
            lines.append(f"  Power Cell: {self.battery_percent:.0f}%")
        if self.cpu_temp_c is not None:
            lines.append(f"  Cogitator Temp: {self.cpu_temp_c:.0f}°C")
        if self.cpu_load_percent is not None:
            lines.append(f"  Cogitator Load: {self.cpu_load_percent:.0f}%")
        lines.append(f"  Warp Link (WiFi): {'CONNECTED' if self.wifi_connected else 'SEVERED'}")
        if self.last_error:
            lines.append(f"  LAST ERROR: {self.last_error}")
        return "\n".join(lines)


@dataclass
class ConversationTurn:
    """Single conversation exchange."""
    role: str  # "user" or "assistant"
    content: str
    timestamp: datetime = field(default_factory=datetime.now)
    has_image: bool = False


class ConversationContext:
    """Manages conversation history and system prompt for the servo-skull."""

    def __init__(self, max_history: int = 6):
        self.max_history = max_history
        self.history: list[ConversationTurn] = []
        self.sensor_status = SensorStatus()
        self._system_prompt: Optional[str] = None

    def load_system_prompt(self) -> str:
        """Load and cache the system prompt with mission parameters."""
        if self._system_prompt is None:
            prompt_path = Path(__file__).parent / "system_prompt.md"
            template = prompt_path.read_text(encoding="utf-8")
            s = get_settings().servo_skull
            self._system_prompt = template.replace("{{MISSION}}", s.mission).replace(
                "{{DESIGNATION}}", s.designation
            ).replace("{{NAME}}", s.name)
        return self._system_prompt

    def add_user_message(self, content: str, has_image: bool = False) -> None:
        """Add user message to history."""
        self.history.append(ConversationTurn(role="user", content=content, has_image=has_image))
        self._trim_history()

    def add_assistant_message(self, content: str) -> None:
        """Add assistant response to history."""
        self.history.append(ConversationTurn(role="assistant", content=content))
        self._trim_history()

    def _trim_history(self) -> None:
        """Keep only recent history within limit."""
        # Each exchange = 2 turns (user + assistant), so max_history * 2 turns
        max_turns = self.max_history * 2
        if len(self.history) > max_turns:
            self.history = self.history[-max_turns:]

    def get_messages(self, include_sensor_status: bool = True, current_image_b64: Optional[str] = None) -> list[dict]:
        """Build OpenRouter-compatible message list."""
        messages = [{"role": "system", "content": self.load_system_prompt()}]

        if include_sensor_status:
            messages.append({"role": "system", "content": self.sensor_status.to_text()})

        for turn in self.history:
            if turn.role == "user" and turn.has_image and current_image_b64:
                messages.append({
                    "role": "user",
                    "content": [
                        {"type": "text", "text": turn.content},
                        {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{current_image_b64}"}}
                    ]
                })
            else:
                messages.append({"role": turn.role, "content": turn.content})

        return messages

    def clear(self) -> None:
        """Reset conversation (new mission)."""
        self.history.clear()

    def get_summary(self) -> str:
        """Brief summary for logging."""
        return f"Turns: {len(self.history)}, Sensor: {'OK' if all([self.sensor_status.camera_ok, self.sensor_status.microphone_ok, self.sensor_status.speaker_ok, self.sensor_status.light_ok]) else 'DEGRADED'}"


def load_system_prompt() -> str:
    """Standalone function to load system prompt."""
    ctx = ConversationContext()
    return ctx.load_system_prompt()